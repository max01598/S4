package com.cdam.envoisms;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && this.checkSelfPermission(android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED )
        {
            requestPermissions( new String[]{android.Manifest.permission.SEND_SMS,}, 1 );
        }
    }

    //Appelé quand l'utilisateur clique sur le bouton send
    public void sendSMS(View view) {
        Context context = getApplicationContext();
        EditText mynum = findViewById(R.id.edit_message);
        EditText myTxt = findViewById(R.id.edit_message2);
        String message = myTxt.getText().toString();
        String num = mynum.getText().toString();
        SmsManager.getDefault().sendTextMessage(num, null,
                message, null, null);
        CharSequence text = "Votre message est : n" + message;
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }


}
