package com.example.myfirstapp;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context context = getApplicationContext();
        String text = "onCreate";
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
        setContentView(R.layout.activity_main);
	
    }

    /*@Override
    protected void onStart(){
        super.onStart();
        Context context = getApplicationContext();
        String text = "onStart";
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
	
    }


    @Override
    public void onResume() {
    	super.onResume();  // Always call the superclass method first

	Context context = getApplicationContext();
	String text = "onResume";
	int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
   }

   @Override
   public void onPause() {
    	super.onPause();  // Always call the superclass method first
	Context context = getApplicationContext();
	String text = "onResume";
	int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
   }
   @Override
   protected void onStop() {
    	// call the superclass method first
   	 super.onStop();
	Context context = getApplicationContext();
	String text = "onResume";
	int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
   }

   @Override
   protected void onDestroy() {
    	// call the superclass method first
   	 super.onDestroy();
	Context context = getApplicationContext();
	String text = "onResume";
	int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
   }*/

//Appelé quand l'utilisateur clique sur le bouton send
    public void displayMessage(View view) {
        Context context = getApplicationContext();
        EditText editText = (EditText) findViewById(R.id.edit_message);
        String message = editText.getText().toString();
        CharSequence text = "Votre message est : n" + message;
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }


}

/*
Décrivez les états possibles d’une application android
Créée :
Lancée :
En pause :
Arrétée :
Détruite :

Décrivez les méthodes principales d’une activité android.
onStart :
onResume :
onRestart :
onPause :
onStop :
 */
