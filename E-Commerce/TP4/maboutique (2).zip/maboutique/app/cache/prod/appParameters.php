<?php return array (
  'parameters' => 
  array (
    'database_host' => '192.168.6.30',
    'database_port' => '',
    'database_name' => 'presta_mdeliot',
    'database_user' => 'mdeliot',
    'database_password' => '3hx7c6i5',
    'database_prefix' => 'ps1_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => NULL,
    'mailer_password' => NULL,
    'secret' => 'r660HuXoBemuQWXET021hDK9oIMWxkkfnKhXIfEkzFAYDIt0y8ogrmKd',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2018-03-14',
    'locale' => 'fr-FR',
    'cookie_key' => '5dUtBSSJOTH8x0P4oYJtcfiBboJqvMY9CNsGyKQDMJDqp9mtEy4h9I3t',
    'cookie_iv' => 'mt97Hj7G',
    'new_cookie_key' => 'def00000ac35c85d525ea10d6c84351d8dce251b5025ff061babdfd4d18ee4f25f06b27bfe7e6aeff593afe1c10778832d26a3582ede586a8fb9db18edc3bfb75ee6bfb2',
  ),
);
