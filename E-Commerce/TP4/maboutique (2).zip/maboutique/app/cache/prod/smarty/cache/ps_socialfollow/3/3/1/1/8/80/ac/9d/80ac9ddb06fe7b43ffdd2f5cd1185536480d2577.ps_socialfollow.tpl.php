<?php /*%%SmartyHeaderCode:12585257465abb43980b6398-74779181%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '80ac9ddb06fe7b43ffdd2f5cd1185536480d2577' => 
    array (
      0 => 'module:ps_socialfollow/ps_socialfollow.tpl',
      1 => 1521036898,
      2 => 'module',
    ),
  ),
  'nocache_hash' => '12585257465abb43980b6398-74779181',
  'variables' => 
  array (
    'social_links' => 0,
    'social_link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5abb43980c47d3_10215763',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5abb43980c47d3_10215763')) {function content_5abb43980c47d3_10215763($_smarty_tpl) {?>

  <div class="block-social col-lg-4 col-md-12 col-sm-12">
    <ul>
          </ul>
  </div>

<?php }} ?>
