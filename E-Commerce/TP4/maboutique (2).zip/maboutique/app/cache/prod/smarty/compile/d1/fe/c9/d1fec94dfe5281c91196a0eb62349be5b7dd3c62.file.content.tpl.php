<?php /* Smarty version Smarty-3.1.19, created on 2018-03-28 09:26:11
         compiled from "C:\wamp\www\maboutique\admin505rzqxnv\themes\default\template\content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18478223195abb43938777b0-20123920%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd1fec94dfe5281c91196a0eb62349be5b7dd3c62' => 
    array (
      0 => 'C:\\wamp\\www\\maboutique\\admin505rzqxnv\\themes\\default\\template\\content.tpl',
      1 => 1521036882,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18478223195abb43938777b0-20123920',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5abb439387a172_64468493',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5abb439387a172_64468493')) {function content_5abb439387a172_64468493($_smarty_tpl) {?>
<div id="ajax_confirmation" class="alert alert-success hide"></div>

<div id="ajaxBox" style="display:none"></div>


<div class="row">
	<div class="col-lg-12">
		<?php if (isset($_smarty_tpl->tpl_vars['content']->value)) {?>
			<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

		<?php }?>
	</div>
</div>
<?php }} ?>
