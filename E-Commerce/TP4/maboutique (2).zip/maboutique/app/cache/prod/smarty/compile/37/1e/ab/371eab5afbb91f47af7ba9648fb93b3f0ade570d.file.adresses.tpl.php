<?php /* Smarty version Smarty-3.1.19, created on 2018-03-28 09:26:15
         compiled from "modules\Adresses\adresses.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20041246165abb4397ec80b6-50391695%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '371eab5afbb91f47af7ba9648fb93b3f0ade570d' => 
    array (
      0 => 'modules\\Adresses\\adresses.tpl',
      1 => 1522221795,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20041246165abb4397ec80b6-50391695',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'nbAd' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5abb4397ec94c5_83484802',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5abb4397ec94c5_83484802')) {function content_5abb4397ec94c5_83484802($_smarty_tpl) {?><div class="block-adresses">
	<a href ="http://localhost/maboutique/adresses">Adresses(<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['nbAd']->value, ENT_QUOTES, 'UTF-8');?>
)</a>
</div><?php }} ?>
