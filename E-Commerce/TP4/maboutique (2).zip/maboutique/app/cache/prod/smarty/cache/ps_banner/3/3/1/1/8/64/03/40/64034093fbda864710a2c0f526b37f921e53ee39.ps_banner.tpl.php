<?php /*%%SmartyHeaderCode:14210936645abb4397db69a5-85912340%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '64034093fbda864710a2c0f526b37f921e53ee39' => 
    array (
      0 => 'module:ps_banner/ps_banner.tpl',
      1 => 1521036896,
      2 => 'module',
    ),
  ),
  'nocache_hash' => '14210936645abb4397db69a5-85912340',
  'variables' => 
  array (
    'banner_link' => 0,
    'banner_desc' => 0,
    'banner_img' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5abb4397dc8c67_88078083',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5abb4397dc8c67_88078083')) {function content_5abb4397dc8c67_88078083($_smarty_tpl) {?><a class="banner" href="http://localhost/maboutique/fr/" title="">
      <img src="http://localhost/maboutique/modules/ps_banner/img/sale70.png" alt="" title="" class="img-fluid">
  </a>
<?php }} ?>
