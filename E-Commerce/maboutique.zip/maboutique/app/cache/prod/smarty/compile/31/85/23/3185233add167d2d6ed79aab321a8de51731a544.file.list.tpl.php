<?php /* Smarty version Smarty-3.1.19, created on 2018-03-14 16:50:37
         compiled from "C:\wamp\www\maboutique\admin505rzqxnv\themes\default\template\helpers\list\list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:334638615aa944cd467bc9-76702200%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3185233add167d2d6ed79aab321a8de51731a544' => 
    array (
      0 => 'C:\\wamp\\www\\maboutique\\admin505rzqxnv\\themes\\default\\template\\helpers\\list\\list.tpl',
      1 => 1521040482,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '334638615aa944cd467bc9-76702200',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'content' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5aa944cd469cb5_50220850',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5aa944cd469cb5_50220850')) {function content_5aa944cd469cb5_50220850($_smarty_tpl) {?>
<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>
