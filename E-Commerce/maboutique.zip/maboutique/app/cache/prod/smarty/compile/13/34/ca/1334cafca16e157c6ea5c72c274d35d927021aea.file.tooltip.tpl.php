<?php /* Smarty version Smarty-3.1.19, created on 2018-03-14 16:40:01
         compiled from "C:\wamp\www\maboutique\modules\welcome\views\templates\tooltip.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10340978155aa94251563497-04306086%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1334cafca16e157c6ea5c72c274d35d927021aea' => 
    array (
      0 => 'C:\\wamp\\www\\maboutique\\modules\\welcome\\views\\templates\\tooltip.tpl',
      1 => 1521040492,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10340978155aa94251563497-04306086',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5aa94251566b37_99532936',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5aa94251566b37_99532936')) {function content_5aa94251566b37_99532936($_smarty_tpl) {?>

<div class="onboarding-tooltip">
  <div class="content"></div>
  <div class="onboarding-tooltipsteps">
    <div class="total"><?php echo smartyTranslate(array('s'=>'Step','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
 <span class="count">1/5</span></div>
    <div class="bulls">
    </div>
  </div>
  <button class="btn btn-primary btn-xs onboarding-button-next"><?php echo smartyTranslate(array('s'=>'Next','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
</button>
</div>
<?php }} ?>
