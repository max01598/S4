<?php /*%%SmartyHeaderCode:15802518325aa94099cca2e0-07617548%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '64034093fbda864710a2c0f526b37f921e53ee39' => 
    array (
      0 => 'module:ps_banner/ps_banner.tpl',
      1 => 1521040495,
      2 => 'module',
    ),
  ),
  'nocache_hash' => '15802518325aa94099cca2e0-07617548',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5ab2785dcf9601_47925290',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ab2785dcf9601_47925290')) {function content_5ab2785dcf9601_47925290($_smarty_tpl) {?><a class="banner" href="http://localhost/maboutique/fr/" title="">
      <img src="http://localhost/maboutique/modules/ps_banner/img/sale70.png" alt="" title="" class="img-fluid">
  </a>
<?php }} ?>
