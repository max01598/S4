<?php /* Smarty version Smarty-3.1.19, created on 2018-03-14 15:33:25
         compiled from "C:\wamp\www\maboutique\admin\themes\default\template\helpers\list\list_action_addstock.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3241407785aa940c525e443-93003338%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '22142452fccf8ebb7505a80f19fa89b16859d5a3' => 
    array (
      0 => 'C:\\wamp\\www\\maboutique\\admin\\themes\\default\\template\\helpers\\list\\list_action_addstock.tpl',
      1 => 1521040482,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3241407785aa940c525e443-93003338',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'href' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5aa940c5261184_48528213',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5aa940c5261184_48528213')) {function content_5aa940c5261184_48528213($_smarty_tpl) {?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_MODIFIER]['escape'][0][0]->smartyEscape($_smarty_tpl->tpl_vars['href']->value,'html','UTF-8');?>
" class="edit btn btn-default" title="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
">
	<i class="icon-circle-arrow-up"></i> <?php echo $_smarty_tpl->tpl_vars['action']->value;?>

</a>
<?php }} ?>
