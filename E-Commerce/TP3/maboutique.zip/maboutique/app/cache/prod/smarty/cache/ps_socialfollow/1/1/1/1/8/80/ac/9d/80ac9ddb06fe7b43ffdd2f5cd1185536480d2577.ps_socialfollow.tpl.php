<?php /*%%SmartyHeaderCode:8486080495aa9409a00aaf7-61295230%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '80ac9ddb06fe7b43ffdd2f5cd1185536480d2577' => 
    array (
      0 => 'module:ps_socialfollow/ps_socialfollow.tpl',
      1 => 1521040496,
      2 => 'module',
    ),
  ),
  'nocache_hash' => '8486080495aa9409a00aaf7-61295230',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5ab2785f971ee3_85091965',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ab2785f971ee3_85091965')) {function content_5ab2785f971ee3_85091965($_smarty_tpl) {?>

  <div class="block-social col-lg-4 col-md-12 col-sm-12">
    <ul>
          </ul>
  </div>

<?php }} ?>
