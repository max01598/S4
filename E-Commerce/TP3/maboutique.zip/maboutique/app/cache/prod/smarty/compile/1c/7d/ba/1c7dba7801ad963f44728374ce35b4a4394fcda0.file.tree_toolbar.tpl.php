<?php /* Smarty version Smarty-3.1.19, created on 2018-03-21 16:26:12
         compiled from "C:\wamp\www\maboutique\admin505rzqxnv\themes\default\template\helpers\tree\tree_toolbar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:154315ab27994a12398-24189847%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1c7dba7801ad963f44728374ce35b4a4394fcda0' => 
    array (
      0 => 'C:\\wamp\\www\\maboutique\\admin505rzqxnv\\themes\\default\\template\\helpers\\tree\\tree_toolbar.tpl',
      1 => 1521040484,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '154315ab27994a12398-24189847',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'actions' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5ab27994a59e11_70659860',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ab27994a59e11_70659860')) {function content_5ab27994a59e11_70659860($_smarty_tpl) {?>
<div class="tree-actions pull-right">
	<?php if (isset($_smarty_tpl->tpl_vars['actions']->value)) {?>
	<?php  $_smarty_tpl->tpl_vars['action'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['action']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['actions']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['action']->key => $_smarty_tpl->tpl_vars['action']->value) {
$_smarty_tpl->tpl_vars['action']->_loop = true;
?>
		<?php echo $_smarty_tpl->tpl_vars['action']->value->render();?>

	<?php } ?>
	<?php }?>
</div>
<?php }} ?>
