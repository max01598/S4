<?php /*%%SmartyHeaderCode:2491944585aa94099d29109-32741359%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8654b2ba7ef103395c5eb0a4a12ed7463d291bc8' => 
    array (
      0 => 'module:ps_customtext/ps_customtext.tpl',
      1 => 1521040489,
      2 => 'module',
    ),
  ),
  'nocache_hash' => '2491944585aa94099d29109-32741359',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5ab2785dd18449_38910537',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ab2785dd18449_38910537')) {function content_5ab2785dd18449_38910537($_smarty_tpl) {?>
<div id="custom-text">
  <h3>Custom Text Block</h3>
<p><strong class="dark">Lorem ipsum dolor sit amet conse ctetu</strong></p>
<p>Sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.</p>
</div>
<?php }} ?>
